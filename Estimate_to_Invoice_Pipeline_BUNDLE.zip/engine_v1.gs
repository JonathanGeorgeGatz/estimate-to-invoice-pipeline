/** Estimate-to-Invoice Pipeline — FIRST BUILD (prompt 1 output), kept verbatim
 *  for the episode. Three real defects live in here:
 *    (1) invoices are matched to jobs BY CUSTOMER NAME — any repeat customer's
 *        second job looks billed the moment their first one is;
 *    (2) the invoice is the acceptance snapshot only — approved change orders
 *        never reach the invoice;
 *    (3) the deposit is taken off the subtotal BEFORE tax is computed, so every
 *        deposited job is under-taxed.
 */
function r2(x) { return Math.round(x * 100) / 100; }
function days(a, b) {
  return Math.round((Date.parse(b + "T00:00:00Z") - Date.parse(a + "T00:00:00Z")) / 86400000);
}

function computePipeline(data, settings) {
  var rate = settings.tax_rate_pct / 100;
  var asOf = data.as_of;
  var linesBy = {};
  data.estimate_lines.forEach(function (l) {
    (linesBy[l.est_id] = linesBy[l.est_id] || []).push(l);
  });
  var estBy = {}, est = [];
  data.estimates.forEach(function (e) {
    var sub = 0, taxable = 0;
    (linesBy[e.est_id] || []).forEach(function (l) {
      var v = r2(l.qty * l.unit_price);
      sub = r2(sub + v);
      if (l.taxable === "Y") taxable = r2(taxable + v);
    });
    // deposit held back first, then tax on what's left of the taxable work
    var deposit = e.status === "ACCEPTED" ? r2(sub * e.deposit_pct / 100) : 0;
    var taxBase = Math.max(0, r2(taxable - deposit));
    var tax = r2(taxBase * rate);
    var total = r2(sub + tax);
    var row = { est_id: e.est_id, customer: e.customer, status: e.status,
      date_sent: e.date_sent, accepted_date: e.accepted_date,
      subtotal: sub, taxableBase: taxable, estTax: tax, estTotal: total,
      deposit: deposit, deposit_pct: e.deposit_pct,
      waitingDays: e.status === "SENT" ? days(e.date_sent, asOf) : 0 };
    estBy[e.est_id] = row; est.push(row);
  });

  var evBy = {};
  data.job_events.forEach(function (ev) { (evBy[ev.job_id] = evBy[ev.job_id] || []).push(ev); });
  // which customers have been invoiced
  var jobCustomer = {};
  data.jobs.forEach(function (j) { jobCustomer[j.job_id] = estBy[j.est_id].customer; });
  var invoicedCustomers = {};
  data.invoices.forEach(function (i) { invoicedCustomers[jobCustomer[i.job_id]] = i.inv_id; });
  var payBy = {};
  data.payments.forEach(function (p) { (payBy[p.inv_id] = payBy[p.inv_id] || []).push(p); });

  var ORDER = { SCHEDULED: 1, STARTED: 2, DONE: 3 };
  var jobs = [], jobByEst = {};
  data.jobs.forEach(function (j) {
    var e = estBy[j.est_id];
    var evs = (evBy[j.job_id] || []).slice().sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    var stage = 0, doneDate = "", lastActivity = j.created_date;
    evs.forEach(function (ev) {
      if (ev.date > lastActivity) lastActivity = ev.date;
      var o = ORDER[ev.event] || 0;
      if (o > stage) stage = o;
      if (ev.event === "DONE" && !doneDate) doneDate = ev.date;
    });
    var due = r2(e.estTotal - e.deposit);     // snapshot only: change orders never surface
    var row = { job_id: j.job_id, est_id: j.est_id, customer: e.customer,
      created_date: j.created_date, stage: stage, doneDate: doneDate,
      lastActivity: lastActivity, pendingCOs: 0, approvedCOTotal: 0,
      invSub: e.subtotal, invTax: e.estTax, invTotal: e.estTotal,
      deposit: e.deposit, amountDue: due,
      stalled: stage === 2 && days(lastActivity, asOf) > settings.stale_days,
      idleDays: days(lastActivity, asOf),
      invoice: invoicedCustomers[e.customer] || "" };
    jobs.push(row); jobByEst[j.est_id] = row;
  });

  var invoices = data.invoices.map(function (i) {
    var j = null;
    for (var k = 0; k < jobs.length; k++) if (jobs[k].job_id === i.job_id) j = jobs[k];
    var paid = 0;
    (payBy[i.inv_id] || []).forEach(function (p) { paid = r2(paid + p.amount); });
    var due = j ? j.amountDue : 0;
    var balance = r2(due - paid);
    var age = days(i.date_sent, asOf);
    var status = balance <= 0.005 ? "PAID"
      : (age > settings.overdue_days ? "OVERDUE" : (paid > 0 ? "PARTIAL" : "SENT"));
    return { inv_id: i.inv_id, job_id: i.job_id, customer: j ? j.customer : "?",
      date_sent: i.date_sent, amountDue: due, paid: paid, balance: balance,
      ageDays: age, status: status, overpaid: balance < -0.005,
      lastPay: (payBy[i.inv_id] || []).reduce(function (m, p) { return p.date > m ? p.date : m; }, "") };
  });

  var board = [], exceptions = [];
  est.forEach(function (e) {
    if (e.status === "SENT")
      board.push({ bucket: "WAITING", id: e.est_id, customer: e.customer,
        value: e.estTotal, daysLabel: e.waitingDays });
    if (e.status === "ACCEPTED" && !jobByEst[e.est_id])
      exceptions.push({ kind: "ACCEPTED_NO_JOB", id: e.est_id, customer: e.customer,
        value: e.estTotal, daysLabel: days(e.accepted_date, asOf) });
  });
  jobs.forEach(function (j) {
    if (j.invoice) return;
    if (j.stage === 3)
      board.push({ bucket: "DONE_NOT_INVOICED", id: j.job_id, customer: j.customer,
        value: j.amountDue, daysLabel: days(j.doneDate, asOf) });
    else if (j.stage === 2)
      board.push({ bucket: j.stalled ? "STALLED" : "IN_PROGRESS", id: j.job_id,
        customer: j.customer, value: j.amountDue, daysLabel: j.idleDays });
    else
      board.push({ bucket: "ACCEPTED_NOT_STARTED", id: j.job_id, customer: j.customer,
        value: j.amountDue, daysLabel: days(j.created_date, asOf) });
  });
  invoices.forEach(function (v) {
    if (v.status === "PAID") {
      if (days(v.lastPay || v.date_sent, asOf) <= settings.paid_window_days)
        board.push({ bucket: "PAID", id: v.inv_id, customer: v.customer,
          value: v.amountDue, daysLabel: days(v.lastPay || v.date_sent, asOf) });
    } else {
      board.push({ bucket: "INVOICED", id: v.inv_id, customer: v.customer,
        value: v.balance, daysLabel: v.ageDays,
        flag: v.status === "OVERDUE" ? "OVERDUE" : (v.status === "PARTIAL" ? "PARTIAL" : "") });
    }
  });

  function sumBucket(name) {
    var t = 0;
    board.forEach(function (b) { if (b.bucket === name) t = r2(t + b.value); });
    return t;
  }
  var totals = {
    waiting: sumBucket("WAITING"), unbilled: sumBucket("DONE_NOT_INVOICED"),
    blocked: 0, inProgress: r2(sumBucket("IN_PROGRESS") + sumBucket("STALLED")),
    outstanding: sumBucket("INVOICED"), overdue: 0, overdueCount: 0,
    unbilledCount: 0, oldestUnbilledDays: 0
  };
  board.forEach(function (b) {
    if (b.bucket === "INVOICED" && b.flag === "OVERDUE") { totals.overdue = r2(totals.overdue + b.value); totals.overdueCount++; }
    if (b.bucket === "DONE_NOT_INVOICED") { totals.unbilledCount++; if (b.daysLabel > totals.oldestUnbilledDays) totals.oldestUnbilledDays = b.daysLabel; }
  });
  return { estimates: est, jobs: jobs, invoices: invoices, board: board,
    exceptions: exceptions, totals: totals,
    reconciliation: { ok: true, rows: [], accepted: 0, placed: 0 } };
}

if (typeof module !== "undefined") module.exports = { computePipeline: computePipeline, r2: r2, days: days };
