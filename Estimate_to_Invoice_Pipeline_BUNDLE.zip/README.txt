THE ESTIMATE-TO-INVOICE PIPELINE
Build It With AI - Episode 9
--------------------------------

One Google Sheet that carries a job from estimate to invoice without retyping,
and a status board that answers the question nothing free seems to answer:
which finished jobs never got billed.

WHAT IT DOES
- Tracks estimates (draft / sent / accepted / declined) with line items.
- One menu click converts accepted estimates into jobs. No retyping.
- Jobs carry events (scheduled / started / done / notes) and change orders.
- One menu click creates invoices for every finished job that is clean to bill.
  A job with a change order still awaiting approval is REFUSED, loudly,
  instead of silently billed wrong.
- The STATUS BOARD: finished-but-never-invoiced (with dollars and days),
  blocked, stalled, overdue invoices, estimates waiting on customers,
  and a reconciliation line that ties every invoice to the cent -
  if it says DOES NOT TIE, do not trust the board, fix the data.

THE MONEY MATH (the spec, so you can check it)
- Estimate: line totals rounded to cents; tax on taxable lines; deposit is
  fixed at acceptance as a percent of the accepted estimate total.
- Invoice: the accepted estimate's lines PLUS approved change orders
  (change orders are taxable). Tax is computed on the FULL taxable base;
  the deposit comes off AFTER tax, never before.
- Matching is by job id, never by customer name. A repeat customer's second
  job can never hide behind their first one's paid invoice.

SET-UP (about 2 minutes)
1. Open a new Google Sheet.
2. Extensions -> Apps Script. Delete what is there, paste ALL of pipeline.gs,
   save.
3. Reload the spreadsheet tab. A "Pipeline" menu appears.
4. Pipeline -> "Set up tabs + sample data" to see it working with the
   fictional Saddle Ridge Exteriors data, or create the same tabs with your
   own rows (keep the header names).
5. Pipeline -> "Rebuild status board".

Settings live on the Settings tab: tax rate, overdue window, stalled window,
how long paid invoices stay on the board, and an as-of date for testing.

FILES IN THIS BUNDLE
- pipeline.gs ............ the whole tool (engine + menu + sample data)
- CLAUDE_PROMPT.txt ...... the exact three prompts from the episode
- engine_v1.gs ........... the FIRST build, bugs and all, for comparison
- checker.py ............. the independent Python checker from the episode
- sample_data/*.csv ...... the sample business as plain CSVs
- fixture.json ........... the same sample business as JSON (checker input)

Everything here is fictional sample data (@example.com). This is a
record-keeping aid, not accounting, tax, or legal advice - your tax
treatment of deposits and change orders may differ; ask your accountant.

Free. No account, no server, no subscription. Your data stays in your sheet.
