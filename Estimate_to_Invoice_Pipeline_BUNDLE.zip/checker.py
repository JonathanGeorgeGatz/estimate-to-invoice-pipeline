#!/usr/bin/env python3
"""Independent checker for the Estimate-to-Invoice Pipeline.

Written FROM THE SPEC in engine.gs's header comment, not from the engine's code:
a second implementation in a second language, structured differently on purpose.
Reads the same business JSON, emits the same report shape for field-by-field
comparison.
"""
import json, sys, math
from datetime import date

def r2(x):
    return math.floor(x * 100 + 0.5) / 100.0

def ndays(a, b):
    return (date.fromisoformat(b) - date.fromisoformat(a)).days

ORDER = {"SCHEDULED": 1, "STARTED": 2, "DONE": 3}

def compute(data, settings):
    rate = settings["tax_rate_pct"] / 100.0
    as_of = data["as_of"]

    lines_by = {}
    for l in data["estimate_lines"]:
        lines_by.setdefault(l["est_id"], []).append(l)

    est_rows, est_by = [], {}
    for e in data["estimates"]:
        sub = 0.0; taxable = 0.0
        for l in lines_by.get(e["est_id"], []):
            v = r2(l["qty"] * l["unit_price"])
            sub = r2(sub + v)
            if l["taxable"] == "Y":
                taxable = r2(taxable + v)
        est_tax = r2(taxable * rate)
        est_total = r2(sub + est_tax)
        deposit = r2(est_total * e["deposit_pct"] / 100.0) if e["status"] == "ACCEPTED" else 0.0
        row = dict(est_id=e["est_id"], customer=e["customer"], status=e["status"],
                   subtotal=sub, taxableBase=taxable, estTax=est_tax, estTotal=est_total,
                   deposit=deposit,
                   waitingDays=ndays(e["date_sent"], as_of) if e["status"] == "SENT" else 0,
                   accepted_date=e["accepted_date"])
        est_rows.append(row); est_by[e["est_id"]] = row

    ev_by, co_by, pay_by = {}, {}, {}
    for ev in data["job_events"]:
        ev_by.setdefault(ev["job_id"], []).append(ev)
    for c in data["change_orders"]:
        co_by.setdefault(c["job_id"], []).append(c)
    for p in data["payments"]:
        pay_by.setdefault(p["inv_id"], []).append(p)
    inv_by_job = {i["job_id"]: i for i in data["invoices"]}

    job_rows, job_by_est = [], {}
    for j in data["jobs"]:
        e = est_by[j["est_id"]]
        evs = sorted(ev_by.get(j["job_id"], []), key=lambda x: x["date"])
        stage = 0; done_date = ""; last_act = j["created_date"]
        for ev in evs:
            if ev["date"] > last_act:
                last_act = ev["date"]
            o = ORDER.get(ev["event"], 0)
            if o > stage:
                stage = o
            if ev["event"] == "DONE" and not done_date:
                done_date = ev["date"]
        cos = co_by.get(j["job_id"], [])
        approved = 0.0; pending = 0
        for c in cos:
            if c["approved"] == "Y":
                approved = r2(approved + c["amount"])
            elif c["approved"] != "N":
                pending += 1
        inv_sub = r2(e["subtotal"] + approved)
        inv_base = r2(e["taxableBase"] + approved)
        inv_tax = r2(inv_base * rate)
        inv_total = r2(inv_sub + inv_tax)
        due = r2(inv_total - e["deposit"])
        idle = ndays(last_act, as_of)
        row = dict(job_id=j["job_id"], est_id=j["est_id"], customer=e["customer"],
                   stage=stage, doneDate=done_date, pendingCOs=pending,
                   approvedCOTotal=approved, invTotal=inv_total, invTax=inv_tax,
                   amountDue=due, deposit=e["deposit"],
                   stalled=(stage == 2 and idle > settings["stale_days"]),
                   idleDays=idle, created_date=j["created_date"],
                   invoice=inv_by_job.get(j["job_id"], {}).get("inv_id", ""))
        job_rows.append(row); job_by_est[j["est_id"]] = row
    job_by_id = {r["job_id"]: r for r in job_rows}

    inv_rows = []
    for i in data["invoices"]:
        j = job_by_id.get(i["job_id"])
        paid = 0.0; last_pay = ""
        for p in pay_by.get(i["inv_id"], []):
            paid = r2(paid + p["amount"])
            if p["date"] > last_pay:
                last_pay = p["date"]
        due = j["amountDue"] if j else 0.0
        bal = r2(due - paid)
        age = ndays(i["date_sent"], as_of)
        if bal <= 0.005:
            status = "PAID"
        elif age > settings["overdue_days"]:
            status = "OVERDUE"
        elif paid > 0:
            status = "PARTIAL"
        else:
            status = "SENT"
        inv_rows.append(dict(inv_id=i["inv_id"], job_id=i["job_id"],
                             customer=j["customer"] if j else "?",
                             amountDue=due, paid=paid, balance=bal, ageDays=age,
                             status=status, overpaid=bal < -0.005,
                             lastPay=last_pay, date_sent=i["date_sent"]))

    board, exceptions = [], []
    for e in est_rows:
        if e["status"] == "SENT":
            board.append(dict(bucket="WAITING", id=e["est_id"], customer=e["customer"],
                              value=e["estTotal"], daysLabel=e["waitingDays"]))
        if e["status"] == "ACCEPTED" and e["est_id"] not in job_by_est:
            exceptions.append(dict(kind="ACCEPTED_NO_JOB", id=e["est_id"], customer=e["customer"],
                                   value=e["estTotal"], daysLabel=ndays(e["accepted_date"], as_of)))
    for j in job_rows:
        if j["invoice"]:
            continue
        if j["pendingCOs"] > 0:
            board.append(dict(bucket="BLOCKED", id=j["job_id"], customer=j["customer"],
                              value=j["amountDue"], daysLabel=j["idleDays"]))
        elif j["stage"] == 3:
            board.append(dict(bucket="DONE_NOT_INVOICED", id=j["job_id"], customer=j["customer"],
                              value=j["amountDue"], daysLabel=ndays(j["doneDate"], as_of)))
        elif j["stage"] == 2:
            board.append(dict(bucket="STALLED" if j["stalled"] else "IN_PROGRESS",
                              id=j["job_id"], customer=j["customer"],
                              value=j["amountDue"], daysLabel=j["idleDays"]))
        else:
            board.append(dict(bucket="ACCEPTED_NOT_STARTED", id=j["job_id"], customer=j["customer"],
                              value=j["amountDue"], daysLabel=ndays(j["created_date"], as_of)))
    for v in inv_rows:
        if v["status"] == "PAID":
            ref = v["lastPay"] or v["date_sent"]
            if ndays(ref, as_of) <= settings["paid_window_days"]:
                board.append(dict(bucket="PAID", id=v["inv_id"], customer=v["customer"],
                                  value=v["amountDue"], daysLabel=ndays(ref, as_of)))
        else:
            flag = "OVERDUE" if v["status"] == "OVERDUE" else ("PARTIAL" if v["status"] == "PARTIAL" else "")
            board.append(dict(bucket="INVOICED", id=v["inv_id"], customer=v["customer"],
                              value=v["balance"], daysLabel=v["ageDays"], flag=flag))
        if v["overpaid"]:
            exceptions.append(dict(kind="OVERPAID", id=v["inv_id"], customer=v["customer"],
                                   value=r2(-v["balance"]), daysLabel=v["ageDays"]))

    def bucket_sum(name):
        t = 0.0
        for b in board:
            if b["bucket"] == name:
                t = r2(t + b["value"])
        return t
    totals = dict(waiting=bucket_sum("WAITING"), unbilled=bucket_sum("DONE_NOT_INVOICED"),
                  blocked=bucket_sum("BLOCKED"),
                  inProgress=r2(bucket_sum("IN_PROGRESS") + bucket_sum("STALLED")),
                  outstanding=bucket_sum("INVOICED"), overdue=0.0, overdueCount=0,
                  unbilledCount=0, oldestUnbilledDays=0)
    for b in board:
        if b["bucket"] == "INVOICED" and b.get("flag") == "OVERDUE":
            totals["overdue"] = r2(totals["overdue"] + b["value"]); totals["overdueCount"] += 1
        if b["bucket"] == "DONE_NOT_INVOICED":
            totals["unbilledCount"] += 1
            totals["oldestUnbilledDays"] = max(totals["oldestUnbilledDays"], b["daysLabel"])

    recon_ok = True
    for v in inv_rows:
        if abs(r2(v["paid"] + v["balance"]) - v["amountDue"]) > 0.005:
            recon_ok = False
    accepted = sum(1 for e in est_rows if e["status"] == "ACCEPTED")
    placed = len(job_rows) + sum(1 for x in exceptions if x["kind"] == "ACCEPTED_NO_JOB")
    if placed != accepted:
        recon_ok = False

    return dict(estimates=est_rows, jobs=job_rows, invoices=inv_rows, board=board,
                exceptions=exceptions, totals=totals,
                reconciliation=dict(ok=recon_ok, accepted=accepted, placed=placed))

if __name__ == "__main__":
    data = json.load(open(sys.argv[1]))
    rep = compute(data, data["settings"] | {"paid_window_days": data["settings"].get("paid_window_days", 30)})
    json.dump(rep, open(sys.argv[2], "w"), indent=1)
    print("checker wrote", sys.argv[2])
